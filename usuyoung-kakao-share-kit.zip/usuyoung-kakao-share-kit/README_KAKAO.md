# 우수영장례식장 예약(카카오 공유) — 3단계 배포

## 1) GitHub Pages에 업로드
1. GitHub에서 새 저장소(example: `usuyoung-reserve`) 생성
2. 이 폴더의 파일 전체 업로드
3. Settings → Pages → Deploy from a branch → `main`/`root` 설정 → 저장
4. 주소 예: `https://YOURNAME.github.io/usuyoung-reserve/`

## 2) 카카오 개발자 콘솔 설정
1. https://developers.kakao.com → 내 애플리케이션 → 애플리케이션 추가
2. 플랫폼 → Web → `https://YOURNAME.github.io` 등록 (필요 시 하위경로 포함)
3. 앱 키 → **JavaScript 키** 복사

## 3) 페이지에서 '무코드' 설정
1. 배포된 페이지 접속 → 우측 상단 **⚙ 설정**
2. **JavaScript 키** 붙여넣기 → 저장
3. (선택) 공유 썸네일 URL에 `https://YOURNAME.github.io/usuyoung-reserve/img/share.png` 입력
4. 예약을 생성하고 **[카카오로 공유]** 클릭

> 공유 링크를 받은 사람은 페이지를 열면 예약 요약이 자동 표시됩니다(개인정보 제외).

### 참고
- 도메인이 `https` 여야 합니다.
- 썸네일은 1200×630 권장(`img/share.png` 기본 제공).
